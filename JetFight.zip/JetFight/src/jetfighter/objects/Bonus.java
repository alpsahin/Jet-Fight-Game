package jetfighter.objects;

import java.awt.Image;

import jetfighter.login.Player;

public class Bonus extends ObjectProperties implements Runnable{
	int speed;
	
	public Bonus(int x, int y, int w, int h, Image image, Plane p){
		super(x, y, w, h, image);
		speed = 10;
	}
	
	@Override
	public void run(){
	}
	
	public void move(){
		setY(getY() + speed);
	}
	
	public void setSpeed(int s){
		speed = s;
	}
	
	
}
