package jetfighter.main;

import jetfighter.login.GameAccountUI;

/**
 * @author AlpSahin
 * 
 * CSE212: SOFTWARE DEVELOPMENT METHODOLOGIES
 * 
 * As term project you are required to develop a single player
 * Jet Fighter game. However, your application should be able to
 * keep scores of active users. For this purpose, the users should
 * be required to register with a login name and a password, and to
 * log in prior playing the game.
 * 
 * */

/**
 * Jet Fighter Game Main Class
 */
public class JetFighter{

	// Game Screen Properties
	private static String GAMETITLE = "Jet Fight";  

	// Main method
	public static void main(String args[]){
		GameAccountUI myLayout = new GameAccountUI();
		myLayout.setTitle(GAMETITLE);       		// Title of the Windows
		myLayout.setLocationRelativeTo(null); 		// Center the frame
		myLayout.setVisible(true);            		// Set Visible
	}
}
// end of the class
